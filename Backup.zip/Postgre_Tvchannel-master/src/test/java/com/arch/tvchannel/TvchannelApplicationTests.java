package com.arch.tvchannel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TvchannelApplicationTests {

    @Test
    void contextLoads() {
    }

}
