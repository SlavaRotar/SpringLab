package com.arch.tvchannel.service.saturday;

import com.arch.tvchannel.model.Monday;
import com.arch.tvchannel.model.Saturday;

public interface ISaturdayService {

    Saturday create (Saturday day);
    Saturday update (Saturday day);

}
