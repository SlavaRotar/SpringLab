package com.arch.tvchannel.service.sunday;

import com.arch.tvchannel.model.Monday;
import com.arch.tvchannel.model.Sunday;

public interface ISundayService {

    Sunday create (Sunday day);
    Sunday update (Sunday day);

}
