package com.arch.tvchannel.service.thursday;

import com.arch.tvchannel.model.Monday;
import com.arch.tvchannel.model.Thursday;

public interface IThursdayService {

    Thursday create (Thursday day);
    Thursday update (Thursday day);

}
