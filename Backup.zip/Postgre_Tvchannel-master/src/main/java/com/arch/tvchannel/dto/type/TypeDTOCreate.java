package com.arch.tvchannel.dto.type;

public class TypeDTOCreate {

    private String name;

    public TypeDTOCreate() {
    }

    public TypeDTOCreate(String name) {
        this.name = name;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
