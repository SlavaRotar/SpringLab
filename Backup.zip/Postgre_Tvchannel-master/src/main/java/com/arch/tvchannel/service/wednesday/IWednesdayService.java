package com.arch.tvchannel.service.wednesday;

import com.arch.tvchannel.model.Monday;
import com.arch.tvchannel.model.Wednesday;

public interface IWednesdayService {

    Wednesday create (Wednesday day);
    Wednesday update (Wednesday day);

}
