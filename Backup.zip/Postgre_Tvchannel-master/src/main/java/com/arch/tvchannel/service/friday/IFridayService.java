package com.arch.tvchannel.service.friday;

import com.arch.tvchannel.model.Friday;
import com.arch.tvchannel.model.Monday;

public interface IFridayService {

    Friday create (Friday day);
    Friday update (Friday day);

}
