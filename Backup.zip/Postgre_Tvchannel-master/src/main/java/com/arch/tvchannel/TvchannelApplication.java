package com.arch.tvchannel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TvchannelApplication {

    public static void main(String[] args) {
        SpringApplication.run(TvchannelApplication.class, args);
    }

}