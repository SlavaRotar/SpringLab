package com.arch.tvchannel.service.monday;

import com.arch.tvchannel.model.Monday;
import com.arch.tvchannel.model.Program;

public interface IMondayService {

    Monday create (Monday day);
    Monday update (Monday day);

}
