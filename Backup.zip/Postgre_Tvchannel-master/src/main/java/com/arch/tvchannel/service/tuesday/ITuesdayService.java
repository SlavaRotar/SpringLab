package com.arch.tvchannel.service.tuesday;

import com.arch.tvchannel.model.Monday;
import com.arch.tvchannel.model.Tuesday;

public interface ITuesdayService {

    Tuesday create (Tuesday day);
    Tuesday update (Tuesday day);

}
